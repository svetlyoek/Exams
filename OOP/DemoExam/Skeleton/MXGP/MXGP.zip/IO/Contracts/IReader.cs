﻿namespace MXGP.IO.Contracts
{
    public interface IReader
    {
        string ReadLine();
    }
}
